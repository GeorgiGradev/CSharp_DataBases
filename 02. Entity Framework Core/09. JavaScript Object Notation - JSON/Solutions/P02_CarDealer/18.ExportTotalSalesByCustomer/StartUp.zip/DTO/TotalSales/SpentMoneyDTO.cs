﻿using Newtonsoft.Json;

namespace CarDealer.DTO.TotalSales
{
    public class SpentMoneyDTO
    {

        public decimal SpentMoney { get; set; }
    }
}
