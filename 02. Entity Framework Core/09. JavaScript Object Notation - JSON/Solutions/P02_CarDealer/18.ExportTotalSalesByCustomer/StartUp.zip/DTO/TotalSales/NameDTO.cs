﻿using Newtonsoft.Json;

namespace CarDealer.DTO.TotalSales
{
    public class NameDTO
    {

        public string Name { get; set; }
    }
}
