﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
   static class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=StudentSystem;Integrated Security=true";
    }
}
