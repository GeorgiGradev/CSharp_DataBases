﻿using AutoMapper;
using ProductShop.Data;

namespace ProductShop
{
    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
          
        }
    }
}
