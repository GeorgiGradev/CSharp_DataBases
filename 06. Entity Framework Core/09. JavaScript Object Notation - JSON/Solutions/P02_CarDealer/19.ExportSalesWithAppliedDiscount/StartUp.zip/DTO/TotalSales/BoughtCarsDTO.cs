﻿using Newtonsoft.Json;

namespace CarDealer.DTO.TotalSales
{
    public class BoughtCarsDTO
    {

        public int BoughtCars { get; set; }
    }
}
