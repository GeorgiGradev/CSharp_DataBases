﻿namespace P03_FootballBetting.Data.Configurations
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=.;Database=FootballBetting;Integrated Security=true";
    }
}
